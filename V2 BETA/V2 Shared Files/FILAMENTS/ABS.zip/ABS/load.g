G10 S250 ; Set current tool temperature
M116 ; Wait for the temperatures to be reached
G1 E50 F600 ; Feed 
G1 E100 F300 ; Feed 
G4 P1000 ; Wait one second
G92 E0
G1 E-5 F600 ; Retract 10mm of filament at 1800mm/min
M98 P"/macros/brush"
M400 ; Wait for moves to complete
G10 S0 ; Turn off the heater again

M291 P"Please wait while the nozzle is being heated up" R"Loading ABS" T5 ; Display message
G10 S250 ; Set current tool temperature to 250C
M116 ; Wait for the temperatures to be reached
M291 P"Feeding filament..." R"Loading ABS" T5 ; Display new message
M83 ; Extruder to relative mode
G1 E150 F300 ; Feed 150mm of filament at 300mm/min
G4 P1000 ; Wait one second
G1 E-10 F900 ; Retract 10mm of filament at 900mm/min
M400 ; Wait for moves to complete
M292 ; Hide the message
G10 S0 ; Turn off the heater again