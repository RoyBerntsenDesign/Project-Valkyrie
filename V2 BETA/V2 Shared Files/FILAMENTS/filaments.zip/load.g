;update values below 
echo "L1"
var filamentType = "TPU"                                                                    ; filamenmnt type
var toolT =240                                                                              ; set hotend temperature     
var dryboxT = 65                                                                            ; set dry box temperature    
var purgeLength = 130                                                                       ; set the length of filament to purge
echo "L2"
; Don't touch anyting beyond this point(unless you know what you're doing)!!
echo "loading", {var.filamentType}
M564 S0                                                                                     ; let travel outside print zone
M400                                                                                        ; Wait for moves to finish
G91 
echo "L3"                                                                                        ; Relative positioning
M83                                                                                         ; Extruder relative positioning
G90                                                                                         ; Absolute positioning
M98 P"/macros/nozzle_park"                                                                  ; Move the nozzle to the bucket defined in the settings section
M400       
echo "L4"                                                                                 ; Wait for moves to finish
M291 P"Please wait while the nozzle is being heated up" R{"Loading " ^ var.filamentType} T5 ; Display message
M568 P0 S{var.toolT}                                                                        ; Set current tool temperature
M116  
echo "L5"                                                                                       ; wait for temperature to be reached 
M291 S4 R"Inset filament" P"Is filament inserted, then press OK." K{"OK","SKIP",}
if input == 0
  M291 P"Feeding filament..." R{"Loading " ^ var.filamentType} T5                           ; Display new me0mode
G1 E{var.purgeLength} F300                                                                  ; purge filament at 3000mm/min
G4 P1000                                                                                    ; Wait one second
G1 E-3 F180                                                                                 ; Retract filament at 1800mm/min
M400    
echo "L6"                                                                                     ; Wait for moves to complete
M292                                                                                        ; Hide the message
G10 S0                                                                                      ; Turn off the heater again
; Set Dry box Temperature 
M291 P{"Dry box temperature being set to " ^ var.dryboxT^"°C"} T5                           ; Display message
M141 P2 S{var.dryboxT}                                                                      ; set drybox temperature
M143 H3 S{var.dryboxT+10} A2   
echo "L7"       
; "SKIP"
if input == 1 
  echo "skipped"
M400                                                                                        ; Wait for moves to finish