;update values below 
var filamentType = "TPU"                                                                      ; filamenmnt type
var toolT =240                                                                                ; set hotend temperature     
var dryboxT =20                                                                               ; set dry box off temperature    
var purgeLength = 60                                                                          ; set the length of filament to purge
var unloadLength = -120                                                                        ; unload length 
echo "U1"
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
; Don't touch anyting beyond this point(unless you know what you're doing)!!
echo "Going to unload", {var.filamentType}
M564 S0                                                                                       ; let travel outside print zone
M400                                                                                          ; Wait for moves to finish
G91                                                                                           ; Relative positioning
M83                                                                                           ; Extruder relative positioning
G90                                                                                           ; Absolute positioning
M98 P"/macros/park_bucket"  
echo "U2"                                                                  ; Move the nozzle to the bucket defined in the settings section
M400                                                                                          ; Wait for moves to finish
M291 P"Please wait while the nozzle is being heated up" R{"Unloading " ^ var.filamentType} T5 ; Display message
M568 P0 S{var.toolT}                                                                        ; Set current tool temperature
M116                                                                                        ; wait for temperature to be reached 
M291 P"Unfeeding filament..." R{"Unloading " ^ var.filamentType} T5                           ; Display new message
M83    
echo "U3"                                                                                       ; Extruder to relative mode
G1 E{var.unloadLength} F300                                                                   ; purge filament at 3000mm/min
G4 P1000                                                                                      ; Wait one second
M400                                                                                          ; Wait for moves to complete
M292                                                                                          ; Hide the message
G10 S0                                                                                        ; Turn off the heater again
; Set Dry box Temperature 
M291 P{"Dry box temperature being set to " ^ var.dryboxT^"°C"} T5    
echo "U4"                         ; Display message
M141 P2 S{var.dryboxT}                                                                        ; set drybox temperature