;pressing the load button on the buffer triggers this 
echo "load  trigger 5"
;load speed need to be at 28mm/s

; Check if Tool 0 (Extruder 0) has a filament loaded
if move.extruders[0].filament = "" 
    M291 P"Load fillament into Buffer and use Load filament in DWC" S2 T10
    
else ; Store the filament name into a variable
    var currentFilament = move.extruders[0].filament
    echo var.currentFilament
    ; Notify user of the detected type
    M291 P{"Detected loaded filament:" ^var.currentFilament} S1 T3
    ; Call the matching unload file using string concatenation
    M98 P{"0:/filaments/" ^ var.currentFilament ^ "/unload.g"}
    M702 P0

