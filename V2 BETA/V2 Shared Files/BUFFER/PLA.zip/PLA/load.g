;update values below 
var filament_type = "PLA"                                                                              ; filamenmnt type
var toolT =220                                                                                         ; set hotend temperature     
var dryboxT = 30                                                                                       ; set dry box temperature    
var purge_length = 80                                                                                  ; set the length of filament to purge
var extruder_pruge_speed = 200 
var load_time_buffer = 20                                                                              ; load buffer time in seconds   

;~~~~~ Don't touch anyting beyond this point(unless you know what you're doing)!! ~~~~~
M98 P"/macros/nozzle_park"                                                                             ; Move the nozzle to the bucket defined in the settings section
M400                                                                                                   ; Wait for moves to finish
M291 S1 P"Please wait while the nozzle is being heated up" R{"Loading " ^ var.filament_type}  T20          ; Display message non blocking
M109 P0 S{var.toolT}                                                                                   ; Set & wait for current tool temperature
M292 P1
echo "filament sensor status",sensors.filamentMonitors[0].status
G1 X310 Y300 F24000                                                                                    ; move tp [place to get less friction in the PTFE tube
;~~~~~~~~~~~~~~~~~~~  feeding filament with buffer~~~~~~~~~~~~~~~~
;use auto feed  on buffer  to feed in fillament , just  insert filament into buffer
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if sensors.filamentMonitors[0].status!="ok"
    M291 S4 R"Inset filament into buffer" P"when Buffer stops feeding, then press OK." K{"OK","SKIP",} ; Display new me0mode
    if input == 0
      M42 P13 S1                                                                                       ; this is to get over friction 
      G4 P500                                                                                          ; Dwell S= seconds P = milliseconds
      M42 P13 S0
      M98 P"/macros/nozzle_park"                                                                       ; Move the nozzle to the bucket defined in the settings section
      M400                                                                                             ; Wait for moves to finish
G1 E{var.purge_length} F{var.extruder_pruge_speed}    
; Set the buffer to pulse
G4 P1000                                                                                               ; Wait one second
G1 E-5 F180                                                                                            ; Retract filament at 1800mm/min
M400                                                                                                   ; Wait for moves to complete
M292                                                                                                   ; Hide the message
G10 S0                                                                                                 ; Turn off the heater again
; Set Dry box Temperature 
M291 P{"Dry box temperature being set to " ^ var.dryboxT^"°C"} T5                                      ; Display message
M141 P3 S{var.dryboxT}                                                                                 ; set drybox temperature
M143 H3 S{var.dryboxT+10} A2         
; "SKIP"
if input == 1 
  echo "skipped"
M400                                                                                                   ; Wait for moves to finish