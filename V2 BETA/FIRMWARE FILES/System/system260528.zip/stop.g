; stop.g  runs after a sucsessfull print 
; called when M0 (Stop) is run (e.g. when a print from SD card is cancelled)
echo "stop.g"
G91
G1 Z5 F3000
G90
M98 P"/macros/nozzle_park" 
M98 P"/macros/nozzle_brush"    
G1 Z300 F3000
G1 E-3 F1800            ; retract filament to stop ooz
M104 S0                 ; turn off Extruder temperature
M140 S0                 ; turn off Bed temperature
M141 P3 R0              ; turn off chamber temperature
echo "turn off motors"
echo "turn off Chamber to be added"
M106 P0 S0
M557 X15:295 Y15:280 P5 ;reset bed mesh same as config 

;~~~~~ Log running time for service interval ~~~~~
M98 P"/sys/log_PrintTime.g"

;~~~~~ Saves the print data to the SD card ~~~~~
echo "stop.g run history logged to sd card"
echo >>"history_job.g" state.time^ ",file," ^ job.file.fileName ^ ",elapsed time," ^ job.duration/60
echo "print time logged"
M98 P"/macros/printTime.g"