; PLA filament configuration
; empty spool weight in grams
; set to -1 if manual spool weight entry is required

set global.spoolWeight = 150
