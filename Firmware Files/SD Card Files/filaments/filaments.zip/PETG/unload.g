; PETG unload.g
; unloads PETG from the extruder and filament buffer

;~~~~~ user settings ~~~~~

var filament_type = "PETG"
var toolT = 250
var dryboxT = 0
var purge_length = 5
var unload_length = 50
var extruder_retract_speed = 200
var unload_time_buffer = 40

;~~~~~ park toolhead and heat nozzle ~~~~~

echo "Going to unload", {var.filament_type}

M98 P"/macros/nozzle_park.g"
M400

M291 S1 P"Please wait while the nozzle is being heated" R{"Unloading " ^ var.filament_type} T15

M109 P0 S{var.toolT}

M291 S1 P"Unfeeding filament..." R{"Unloading " ^ var.filament_type}

;~~~~~ unload filament from extruder ~~~~~

M83

G1 E{var.purge_length} F{var.extruder_retract_speed}
G1 E{-var.unload_length} F{var.extruder_retract_speed}

M400

G10 P0 S0

;~~~~~ unload filament through buffer ~~~~~

M42 P14 S1
G4 S{var.unload_time_buffer}
M42 P14 S0

M292

;~~~~~ prompt user to remove filament ~~~~~

M291 S1 P"Remove filament from buffer" R{"Unloading " ^ var.filament_type} T15

;~~~~~ set drybox temperature ~~~~~

M291 S1 P{"Dry box temperature being set to " ^ var.dryboxT ^ "°C"} R"Dry Box" T5

M141 P1 S{var.dryboxT}

;~~~~~ turn off drybox ~~~~~

M141 P1 S-273.1 R0