; PETG load.g
; heats the nozzle, reminds the user to verify filament position,
; purges the nozzle, brushes the nozzle and sets the drybox temperature

;~~~~~ user settings ~~~~~

var filament_type = "PETG"
var toolT = 275
var dryboxT = 50
var purge_length = 100
var extruder_purge_speed = 300

;~~~~~ park toolhead ~~~~~

M98 P"/macros/nozzle_park.g"
M400

;~~~~~ heat nozzle and remind user ~~~~~

M291 S1 R{"Loading " ^ var.filament_type} P"Make sure the filament has reached the toolhead" T20

M109 P0 S{var.toolT}

M292

;~~~~~ feed and purge filament ~~~~~

M83
G1 E{var.purge_length} F{var.extruder_purge_speed}
G4 P1000
G1 E-5 F180
M400

G10 P0 S0

;~~~~~ brush nozzle ~~~~~

M98 P"/macros/nozzle_brush.g"
M400

;~~~~~ set drybox temperature ~~~~~

M291 S1 R"Dry Box" P{"Temperature being set to " ^ var.dryboxT ^ "°C"} T5

M141 P1 S{var.dryboxT}
M143 H3 S{var.dryboxT + 10} A2

M400