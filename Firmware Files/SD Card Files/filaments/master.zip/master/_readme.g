1. Open config.g file - update the spool weight & save:

2. Open the load.g file update the following variables:
var filament_type = "enter filament type" ; filament type
var toolT =230                            ; set hotend temperature     
var dryboxT = 40                          ; set dry box temperature    
var purge_length = 90                     ; set the length of filament to purge
var extruder_pruge_speed = 200            ; purge speed in mm/min
var load_time_buffer = 20                 ; load buffer time in seconds   
set global.spoolWeight = 125              ; enter the spool weight set to -1 for manual filament weight entry  
- save

3. Open the unload.g update the following variables:
var filament_type = "Enter Filament type" ; filament type
var toolT = 220                           ; set hotend temperature     
var dryboxT = 20                          ; set dry box off temperature    
var purge_length = 5                      ; set the length of filament to purge
var unload_length = 80                    ; set the unload  length of filament   
var extruder_retract_speed = 200          ; set the retract speed of the extruder 
var unload_time_buffer = 50               ; unload buffer time in seconds 	                                                                                          ;       
set global.spoolWeight = 0                ; enter the spool weight set to -1 for manual filament weight entry  
- save